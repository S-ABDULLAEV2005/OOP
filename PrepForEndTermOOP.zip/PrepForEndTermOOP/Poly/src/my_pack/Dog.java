package my_pack;

public class Dog {
  public void voice(){
	  System.out.println("Gauw gauw!");
  }
}
