package my_pack;

public class Cat {
	public void voice(){
		  System.out.println("Meuw, meuw!");
	  }
}
