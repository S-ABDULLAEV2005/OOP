package my_pack;

public class Hen {
	public void voice(){
		  System.out.println("Kukarokoooo!");
	  }
}
