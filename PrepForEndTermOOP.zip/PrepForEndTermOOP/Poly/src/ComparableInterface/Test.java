package ComparableInterface;
import java.util.*;
public class Test {
  public static void main(String[] args) {
	  List<Compare> l = new ArrayList<>();
      l.add(new Compare("Shakha", 18)); 
      l.add(new Compare("Bakha", 18)); 
      l.add(new Compare("John", 19)); 
      l.add(new Compare("Murod", 18)); 
      l.add(new Compare("Komron", 20 )); 
  
  }
}
