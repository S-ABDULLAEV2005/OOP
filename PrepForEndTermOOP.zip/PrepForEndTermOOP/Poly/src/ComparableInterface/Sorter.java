package ComparableInterface;

public class Sorter {

}
