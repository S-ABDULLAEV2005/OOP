package prepend;
import java.util.*;
public class Person {
 private String name;
 private String surname;
 private Date dateOfBirth;
 private String contactInformation;
  
 public Person(String name, String surname, Date dateOfBirth, String contactInformation) {
	 this.name = name;
	 this.surname = surname;
	 this.dateOfBirth = dateOfBirth;
	 this.contactInformation = contactInformation;
 }
}
