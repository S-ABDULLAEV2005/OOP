/**
 * 
 */
/**
 * 
 */
module Pattern {
}