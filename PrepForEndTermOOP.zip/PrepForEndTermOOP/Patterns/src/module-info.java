/**
 * 
 */
/**
 * 
 */
module Patterns {
}